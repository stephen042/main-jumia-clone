$(document).ready(function() {

    $('#bars').click(function() {
        // $('.jumia-box3').slideUp(2000)
        $('.jumia-box3').slideToggle(2000)
    })
})
   